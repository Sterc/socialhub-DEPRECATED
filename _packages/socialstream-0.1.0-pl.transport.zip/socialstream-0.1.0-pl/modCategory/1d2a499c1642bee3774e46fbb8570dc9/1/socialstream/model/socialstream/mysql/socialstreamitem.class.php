<?php
require_once (dirname(dirname(__FILE__)) . '/socialstreamitem.class.php');
class SocialStreamItem_mysql extends SocialStreamItem {}