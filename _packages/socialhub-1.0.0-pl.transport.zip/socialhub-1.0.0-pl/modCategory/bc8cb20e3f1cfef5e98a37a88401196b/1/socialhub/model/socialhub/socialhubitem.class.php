<?php
/**
 * @package socialhub
 */
class SocialHubItem extends xPDOSimpleObject
{

}
