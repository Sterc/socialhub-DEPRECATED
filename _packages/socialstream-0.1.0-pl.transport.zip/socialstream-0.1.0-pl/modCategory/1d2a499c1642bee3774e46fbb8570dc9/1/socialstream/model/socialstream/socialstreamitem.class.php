<?php
/**
 * @package socialstream
 */
class SocialStreamItem extends xPDOSimpleObject
{

}
